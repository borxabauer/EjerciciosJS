const numbers = [0,1,2];
let sum = 0;

for (let item of numbers) {
    sum = sum + item;
    
}

console.log(sum)