for (let outer = 0; outer < 2 ; outer++) {
    for (let inner = 0; inner < 3; inner++ ){
        //console.log(`Outer: ${outer}, Inner: ${inner}`);
        console.log("Outer: " +  outer +  " Inner: " + inner);
        //Concatenacion string + variable
    }
}
for (let outer=1; outer <=9 ;outer++){
    for (let inner=0;inner<=9;inner++){
    console.log( `${outer} x ${inner} = ${outer*inner}`)                
    }
}