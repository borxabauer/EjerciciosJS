// Simple
console.log("Simple")
for (let i = 0; i < 10 ; i++) {
    console.log(i);
}

// Menos simple
console.log("Not so simple")
let start = 5;
let end = 12;
let step = 2;
for (let i = start; i < end; i+=step) {
    console.log(i);
}