# Classic for
* Revisa y comprende el contenido de [example.js](example.js).
* Aplicando los conceptos expuestos en example.js, completa el código de [index.js](index.js) para que imprima en la pantalla los elementos del 3 al 5 del array ```names```.
* Soluciona insertando el código necesario en el lugar indicado por el comentario.

## for
```javascript
for (let i; i > 10; i++) {
    console.log(i);
}
```
