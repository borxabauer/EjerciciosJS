const people = ["Mortadelo", "Filemon", "Ofelia", "Bacterio"];
let counter = 0;


for (let i of people) {
    counter++;
}
console.log(counter);
