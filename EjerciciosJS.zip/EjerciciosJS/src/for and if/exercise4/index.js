const numbers = [0,1,2];

for (let item of numbers) {
    let sum = 0;
    sum += item;
}

console.log(sum)