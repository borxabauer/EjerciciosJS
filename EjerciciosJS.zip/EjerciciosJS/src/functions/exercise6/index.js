const numbers = [11,9,13,12]

// Paste your functions here

// Put your code here

console.log(numbers);